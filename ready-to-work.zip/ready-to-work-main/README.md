# ready-to-work
This is a ready to use "REACT" template fused with bootstrap, jquery & react-router-dom.
